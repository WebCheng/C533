import random
import numpy as np
import ray


# Taken from baseline code
@ray.remote
class ReplayBuffer_remote(object):
    def __init__(self, size, test_interval, training_episodes):
        """Create Replay buffer.
        Parameters
        ----------
        size: int
            Max number of transitions to store in the buffer. When the buffer
            overflows the old memories are dropped.
        """
        self._storage = []
        self._maxsize = size
        self._next_idx = 0
        self.results = []
        self.evadirs = []
#         self.evadirs = [
# 'best_model100.pt',  'best_model32.pt', 'best_model55.pt', 'best_model78.pt',
# 'best_model10.pt',   'best_model33.pt', 'best_model56.pt', 'best_model79.pt',
# 'best_model11.pt',   'best_model34.pt', 'best_model57.pt', 'best_model7.pt',
# 'best_model12.pt',   'best_model35.pt', 'best_model58.pt', 'best_model80.pt',
# 'best_model13.pt',   'best_model36.pt', 'best_model59.pt', 'best_model81.pt',
# 'best_model14.pt',   'best_model37.pt', 'best_model5.pt',  'best_model82.pt',
# 'best_model15.pt',   'best_model38.pt', 'best_model60.pt', 'best_model83.pt',
# 'best_model16.pt',   'best_model39.pt', 'best_model61.pt', 'best_model84.pt',
# 'best_model17.pt',   'best_model3.pt',  'best_model62.pt', 'best_model85.pt',
# 'best_model18.pt',   'best_model40.pt', 'best_model63.pt', 'best_model86.pt',
# 'best_model19.pt',   'best_model41.pt', 'best_model64.pt', 'best_model87.pt',
# 'best_model1.pt',    'best_model42.pt', 'best_model65.pt', 'best_model88.pt',
# 'best_model20.pt',   'best_model43.pt', 'best_model66.pt', 'best_model89.pt',
# 'best_model21.pt',   'best_model44.pt', 'best_model67.pt', 'best_model8.pt',
# 'best_model22.pt',   'best_model45.pt', 'best_model68.pt', 'best_model90.pt',
# 'best_model23.pt',   'best_model46.pt', 'best_model69.pt', 'best_model91.pt',
# 'best_model24.pt',   'best_model47.pt', 'best_model6.pt',  'best_model92.pt',
# 'best_model25.pt',   'best_model48.pt', 'best_model70.pt', 'best_model93.pt',
# 'best_model26.pt',   'best_model49.pt', 'best_model71.pt', 'best_model94.pt',
# 'best_model27.pt',   'best_model4.pt',  'best_model72.pt', 'best_model95.pt',
# 'best_model28.pt',   'best_model50.pt', 'best_model73.pt', 'best_model96.pt',
# 'best_model29.pt',   'best_model51.pt', 'best_model74.pt', 'best_model97.pt',
# 'best_model2.pt',    'best_model52.pt', 'best_model75.pt', 'best_model98.pt',
# 'best_model30.pt',   'best_model53.pt', 'best_model76.pt', 'best_model99.pt',
# 'best_model31.pt',   'best_model54.pt', 'best_model77.pt', 'best_model9.pt'
#         ]
    
    
        self.evaluate_cnt = 0
        self.test_interval = test_interval
        self.training_episodes = training_episodes

    def __len__(self):
        return len(self._storage)

    def length(self):
        return len(self._storage)

    def add_evamodel_dir(self, dir):
        self.evadirs.append(dir)

    def get_evaluate_filedir(self):
        if len(self.evadirs) == 0:
            return None, ((self.evaluate_cnt * self.test_interval) >= self.training_episodes)
        self.evaluate_cnt += 1
#         return ".//CartPole-distributed//"+self.evadirs.pop(0), ((self.evaluate_cnt * self.test_interval) >= self.training_episodes)
        return self.evadirs.pop(0), ((self.evaluate_cnt * self.test_interval) >= self.training_episodes)

    def add(self, obs_t, action, reward, obs_tp1, done):
        data = (obs_t, action, reward, obs_tp1, done)

        if self._next_idx >= len(self._storage):
            self._storage.append(data)
        else:
            self._storage[self._next_idx] = data
        self._next_idx = (self._next_idx + 1) % self._maxsize

    def _encode_sample(self, idxes):
        obses_t, actions, rewards, obses_tp1, dones = [], [], [], [], []
        for i in idxes:
            data = self._storage[i]
            obs_t, action, reward, obs_tp1, done = data
            obses_t.append(np.array(obs_t, copy=False))
            actions.append(np.array(action, copy=False))
            rewards.append(reward)
            obses_tp1.append(np.array(obs_tp1, copy=False))
            dones.append(done)
        return (np.array(obses_t),
                np.array(actions),
                np.array(rewards),
                np.array(obses_tp1),
                np.array(dones))

    def add_results(self, avg_reward):
        self.results.append(avg_reward)

    def get_results(self):
        return self.results

    def sample(self, batch_size):
        """Sample a batch of experiences.
        Parameters
        ----------
        batch_size: int
            How many transitions to sample.
        Returns
        -------
        obs_batch: np.array
            batch of observations
        act_batch: np.array
            batch of actions executed given obs_batch
        rew_batch: np.array
            rewards received as results of executing act_batch
        next_obs_batch: np.array
            next set of observations seen after executing act_batch
        done_mask: np.array
            done_mask[i] = 1 if executing act_batch[i] resulted in
            the end of an episode and 0 otherwise.
        """
        if len(self._storage) <= batch_size:
            return None
        idxes = [random.randint(0, len(self._storage) - 1) for _ in range(batch_size)]
        return self._encode_sample(idxes)